﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace StudentManagementSystem
{
    public partial class logIn : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=|DataDirectory|\\DB.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void loginButton_Click(object sender, EventArgs e)
        {
            string login = "select count(*) from [user] where Name='"+usernameTextBox.Text+"' and Password='"+passwordTextBox.Text+"'";
            SqlCommand com = new SqlCommand(login, con);
            con.Open();
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            con.Close();
            if(temp==1)
            {
                Response.Redirect("home.aspx");
            }
            else
            {
                Response.Redirect("login.aspx");
            }

        }

        protected void cancelButton_Click(object sender, EventArgs e)
        {
            usernameTextBox.Text = String.Empty;
            passwordTextBox.Text = String.Empty;
        }
    }
}