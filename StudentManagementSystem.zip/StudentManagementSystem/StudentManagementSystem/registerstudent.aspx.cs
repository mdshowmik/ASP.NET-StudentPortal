﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManagementSystem
{
    public partial class registerstudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=|DataDirectory|\\DB.mdf;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            successfullLabel.Text = "";
        }

        protected void cancelregistrationButton_Click(object sender, EventArgs e)
        {
            studentnameTextBox.Text = String.Empty;
            studentclassTextBox.Text = String.Empty;
            studentphoneTextBox.Text = String.Empty;
        }

        protected void submitButton_Click(object sender, EventArgs e)
        {
            if (studentnameTextBox.Text.Trim() != "" && studentclassTextBox.Text.Trim() != "" && studentphoneTextBox.Text.Trim() != "")
            {
                string registrationInput = "Insert into [student_info](Name, Phone, Class) values ('" + studentnameTextBox.Text + "', '" + studentphoneTextBox.Text + "', '" + studentclassTextBox.Text + "')";
                string marksheetInput = "Insert into [mark_sheet](Name, Bangla, English, Math, Science) values ('" + studentnameTextBox.Text + "', '0', '0', '0', '0')";
                SqlCommand comInfo = new SqlCommand(registrationInput, con);
                SqlCommand comMark = new SqlCommand(marksheetInput, con);
                con.Open();
                comInfo.ExecuteNonQuery();
                comMark.ExecuteNonQuery();
                con.Close();
                successfullLabel.Text = "Successfull";
                studentnameTextBox.Text = String.Empty;
                studentclassTextBox.Text = String.Empty;
                studentphoneTextBox.Text = String.Empty;
            }
            else
            {
                successfullLabel.Text = "Incomplete Information";
            }
        }
    }
}