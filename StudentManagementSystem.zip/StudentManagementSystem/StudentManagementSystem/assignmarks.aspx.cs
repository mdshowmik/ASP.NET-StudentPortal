﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManagementSystem
{
    public partial class assignmarks : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=|DataDirectory|\\DB.mdf;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            marksheetidTextBox.Text = Request.QueryString["Id"];
        }

        protected void marksheetsubmitButton_Click(object sender, EventArgs e)
        {
            if(banglaTextBox.Text != "" && englishTextBox.Text != "" && mathTextBox.Text != "" && scienceTextBox.Text != "")
            {
                string marksInput = "Update [mark_sheet] set Bangla = '" + banglaTextBox.Text + "', English = '" + englishTextBox.Text + "', Math = '" + mathTextBox.Text + "', Science = '" + scienceTextBox.Text + "' where Id = '" + marksheetidTextBox.Text + "' ";
                SqlCommand comMarksInput = new SqlCommand(marksInput, con);
                con.Open();
                comMarksInput.ExecuteNonQuery();
                con.Close();
                markssubmitLabel.Text = "Successfull";
                banglaTextBox.Text = String.Empty;
                englishTextBox.Text = String.Empty;
                mathTextBox.Text = String.Empty;
                scienceTextBox.Text = String.Empty;
            }
            else
            {
                markssubmitLabel.Text = "Unsuccessful";
            }
        }

        protected void marksheetcancelButton_Click(object sender, EventArgs e)
        {
            markssubmitLabel.Text = "";
            banglaTextBox.Text = String.Empty;
            englishTextBox.Text = String.Empty;
            mathTextBox.Text = String.Empty;
            scienceTextBox.Text = String.Empty;
        }
    }
}